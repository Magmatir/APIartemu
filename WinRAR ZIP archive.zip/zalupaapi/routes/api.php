<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BoardingStatementsController;
use App\Http\Controllers\ClientsInfosController;
use App\Http\Controllers\RacesInfosController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('boarding_statements')->group(function() {
    Route::get('/', [BoardingStatementsController::class, 'index']);
    Route::post('/', [BoardingStatementsController::class, 'store']);
    Route::put('/', [BoardingStatementsController::class, 'update']);
    Route::delete('/{id}', [BoardingStatementsController::class, 'destroy']);
});

Route::prefix('clients_infos')->group(function() {
    Route::get('/', [ClientsInfosController::class, 'index']);
    Route::post('/', [ClientsInfosController::class, 'store']);
    Route::put('/', [ClientsInfosController::class, 'update']);
    Route::delete('/{id}', [ClientsInfosController::class, 'destroy']);
});

Route::prefix('races_infos')->group(function() {
    Route::get('/', [RacesInfosController::class, 'index']);
    Route::post('/', [RacesInfosController::class, 'store']);
    Route::put('/', [RacesInfosController::class, 'update']);
    Route::delete('/{id}', [RacesInfosController::class, 'destroy']);
});


