<?php

namespace App\Http\Controllers;

use App\Models\BoardingStatement;
use Illuminate\Http\Request;


class BoardingStatementsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $event = BoardingStatement::all();
        return $event;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
    
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $event = New BoardingStatement;
        
        $event->fio = $request->fio;
        $event->serial_number = $request->serial_number;
        $event->bilet_number = $request->bilet_number;
        $event->race_number = $request->race_number;
        $event->final_amount = $request->final_amount;
        $event->races_info_id = $request->races_info_id;
        $event->clients_info_id = $request->clients_info_id;
        $event->updated_at = $request->updated_at;
        $event->created_at = $request->created_at;
        
        $event->Save();

        return $event;
    }

    /**
     * Display the specified resource.
     */
    public function show(boarding_statements $boarding_statements)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(boarding_statements $boarding_statements)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $event = BoardingStatement::find($request->id);
        
        $event->fio = $request->fio;
        $event->serial_number = $request->serial_number;
        $event->bilet_number = $request->bilet_number;
        $event->race_number = $request->race_number;
        $event->final_amount = $request->final_amount;
        $event->races_info_id = $request->races_info_id;
        $event->clients_info_id = $request->clients_info_id;
        $event->updated_at = $request->updated_at;
        $event->created_at = $request->created_at;
        
        $event->Save();

        return true;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        BoardingStatement::destroy($id);

        return true;
    }
}
