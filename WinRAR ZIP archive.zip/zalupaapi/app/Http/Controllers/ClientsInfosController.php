<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ClientInfo;

class ClientsInfosController extends Controller
{
    public function index()
    {
        $event = ClientsInfo::all();
        return $event;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
    
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $event = New ClientsInfo;
        
        $event->fio = $request->fio;
        $event->seria_number = $request->seria_number;
        $event->place_alive = $request->place_alive;
        $event->number_visa = $request->number_visa;
        $event->updated_at = $request->updated_at;
        $event->created_at = $request->created_at;
        
        $event->Save();

        return $event;
    }

    /**
     * Display the specified resource.
     */
    public function show(clients_infos $clients_infos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(clients_infos $clients_infos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $event = ClientsInfo::find($request->id);
        
        $event->fio = $request->fio;
        $event->seria_number = $request->seria_number;
        $event->place_alive = $request->place_alive;
        $event->number_visa = $request->number_visa;
        $event->updated_at = $request->updated_at;
        $event->created_at = $request->created_at;
        
        $event->Save();

        return true;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        ClientsInfo::destroy($id);

        return true;
    }
}
