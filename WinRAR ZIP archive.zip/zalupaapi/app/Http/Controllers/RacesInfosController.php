<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RacesInfo;

class RacesInfosController extends Controller
{
    public function index()
    {
        $event = RacesInfo::all();
        return $event;
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
    
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $event = New RacesInfo;
        
        $event->date_start = $request->date_start;
        $event->name_of_way = $request->name_of_way;
        $event->amount_selled_bilets = $request->amount_selled_bilets;
        $event->revenue = $request->revenue;
        $event->updated_at = $request->updated_at;
        $event->created_at = $request->created_at;
        
        $event->Save();

        return $event;
    }

    /**
     * Display the specified resource.
     */
    public function show(races_infos $races_infos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(races_infos $races_infos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $event = RacesInfo::find($request->id);
        
        $event->date_start = $request->date_start;
        $event->name_of_way = $request->name_of_way;
        $event->amount_selled_bilets = $request->amount_selled_bilets;
        $event->revenue = $request->revenue;
        $event->updated_at = $request->updated_at;
        $event->created_at = $request->created_at;
        
        $event->Save();

        return true;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        RacesInfo::destroy($id);

        return true;
    }
}
