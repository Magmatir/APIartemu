<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BoardingStatement extends Model
{
    use HasFactory;

    protected $fillable = [
                            'fio', 
                            'serial_number', 
                            'bilet_number', 
                            'race_number', 
                            'final_amount', 
                            'races_info_id', 
                            'clients_info_id', 
                             ];
    
    public function ClientInfo() {
        return $this->belongsTo(ClientInfo::class, "clients_info_id", "id");
    }
    
    public function RaceInfo() {
        return $this->belongsTo(RaceInfo::class, "races_info_id", "id");
    }    
}
