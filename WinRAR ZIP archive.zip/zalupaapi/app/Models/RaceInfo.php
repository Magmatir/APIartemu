<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RaceInfo extends Model
{
    use HasFactory;

    protected $fillable = [ 'date_start',
                            'name_of_way',
                            'amount_selled_bilets',
                            'revenue'
                            ];
}
